# Training Pipeline — Model Custom Deteksi Janjang, Brondol & Janjang Kosong

Folder ini berisi panduan & script untuk melatih model deteksi objek
custom begitu Anda sudah punya kumpulan foto janjang/brondol dari
lapangan. Hasil akhirnya adalah file `.tflite` yang tinggal ditaruh di
`assets/models/sawit_detector.tflite` pada project Flutter, lalu aktifkan
mode "Model Custom (TFLite)" di layar Settings aplikasi.

Aplikasi SawitVision **tidak wajib** menunggu tahap ini — mode "CV Klasik"
sudah bisa dipakai sekarang tanpa training apapun. Pipeline ini untuk
meningkatkan akurasi setelah Anda mengumpulkan cukup data.

## 1. Kumpulkan data (paling penting)

- Target awal: 300–500 foto per kelas (`janjang`, `brondol`, `janjang_kosong`
  — tandan tanpa buah/rontok total, setara Fraksi 5), makin banyak makin baik.
  `janjang_kosong` wajar jumlahnya jauh lebih sedikit di lapangan — itu tidak
  masalah, tapi usahakan tetap ada beberapa contoh supaya model bisa belajar
  mengenalinya, bukan cuma "janjang biasa" vs "brondol".
- Variasikan: kondisi cahaya (pagi/siang/mendung), sudut foto, tingkat
  kematangan, latar (tanah, TPH beton, rumput), jarak kamera.
- Simpan foto asli (jangan di-crop dulu) — resolusi 1280–1920px cukup.
- Beri nama file yang jelas per lokasi/tanggal agar mudah ditelusuri.

## 2. Beri label (anotasi)

### Opsi A — pakai halaman "Koreksi Data" di web dashboard (disarankan)

Paket `sawit_vision_web` punya halaman `koreksi.html` khusus untuk kasus
SawitVision: gambar bounding box per objek — 🟢 janjang, 🟠 tumpukan brondol,
🔴 janjang kosong — sekaligus koreksi jumlah final per foto. Berguna terutama
untuk foto yang diimpor dari sumber lain (mis. sistem e-Panen internal) yang
jumlah JJG/BRD di levelnya cuma agregat per batch, belum tentu cocok persis
dengan 1 foto tertentu. Foto selalu ditampilkan utuh (landscape maupun
potret, termasuk tanggal/jam yang tercetak di foto) supaya mudah didefine.

1. Buka `koreksi.html` di browser (tidak perlu setup Supabase — semua
   proses terjadi lokal di browser).
2. Pilih semua foto 1 batch sekaligus (mis. folder `raw_batches/<nama>/`
   di bawah).
3. Untuk tiap foto: pilih jenis objek dulu (Janjang / Tumpukan Brondol /
   Janjang Kosong), lalu gambar kotak di tiap objek yang terlihat, isi
   jumlah final, centang "Sudah saya periksa & koreksi". Tandan tanpa buah
   sama sekali (rontok total) masuk kategori "Janjang Kosong", bukan
   "Janjang" biasa.
4. Klik **Export Anotasi (JSON)** — hasilnya `sawitvision_annotations.json`.
5. Konversi ke format YOLO:
   ```bash
   python convert_web_annotations.py \
     --json sawitvision_annotations.json \
     --images raw_batches/<nama_batch> \
     --out raw
   ```
   Ini menghasilkan `raw/images/`, `raw/labels/` (YOLO), dan
   `raw/sawitvision_labels.csv` (ringkasan jumlah final per foto, dipakai
   untuk kalibrasi grading — bukan untuk training model deteksi).

Foto-foto mentah per batch disimpan di `raw_batches/<tanggal>_<sumber>/`
(lihat folder `raw_batches/2026-07-16_SRIE1_TATA/` sebagai contoh batch
pertama) — nama file JANGAN diubah karena `koreksi.html` mencocokkan
anotasi ke file berdasarkan nama persis.

### Opsi B — tools eksternal

Alternatif lain kalau lebih suka tools mandiri:

- [Roboflow](https://roboflow.com) (berbasis web, ada tier gratis,
  langsung bisa export ke format YOLO)
- [CVAT](https://www.cvat.ai) (open source, bisa self-host)
- [LabelImg](https://github.com/HumanSignal/labelImg) (ringan, offline)

Export hasil label dalam format **YOLO** (`.txt` per gambar, 1 baris per
objek: `class_id x_center y_center width height`, semua ternormalisasi
0–1) langsung ke struktur `raw/images` + `raw/labels` di bawah.

Struktur folder yang diharapkan skrip di bawah:

```
dataset/
  images/
    train/*.jpg
    val/*.jpg
  labels/
    train/*.txt
    val/*.txt
  data.yaml
```

`prepare_dataset.py` membantu membagi otomatis data mentah menjadi
train/val dengan rasio 80/20.

## 3. Install dependency training (di komputer/laptop, BUKAN di HP)

```bash
pip install -r requirements.txt
```

## 4. Latih model

```bash
python train_yolov8.py --data dataset/data.yaml --epochs 100 --imgsz 320
```

Model kecil (`yolov8n`) dipilih sebagai default karena harus jalan cepat
di HP. Sesuaikan `--epochs`/`--imgsz` sesuai kebutuhan akurasi vs ukuran
model.

## 5. Export ke TFLite

```bash
python export_to_tflite.py --weights runs/detect/train/weights/best.pt
```

Script ini menghasilkan `best_float16.tflite` (atau sesuai opsi
kuantisasi). Rename jadi `sawit_detector.tflite`, taruh di
`assets/models/` pada project Flutter, lalu update `labels.txt` di
`assets/labels/` sesuai urutan kelas di `data.yaml`.

## 6. Sesuaikan kode aplikasi jika perlu

`lib/services/tflite_detection_service.dart` mengasumsikan output model
bergaya YOLOv8 (`[1, N, 5+num_classes]`). Jika Anda mengganti arsitektur
model (mis. SSD MobileNet, EfficientDet), sesuaikan method
`_parseYoloOutput` di file tersebut dengan format output model Anda.
